public class Environment {

    public int put(String var, int val) { return val; }
    public int get(int pos, String var) throws EvalException { return 0; }

}
