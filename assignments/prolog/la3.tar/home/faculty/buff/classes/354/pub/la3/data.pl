free(ann,slot(time(8,0),time(9,0))).
free(ann,slot(time(10,0),time(11,0))).

free(bob,slot(time(7,0),time(8,30))).
free(bob,slot(time(10,0),time(11,0))).

free(carla,slot(time(8,0),time(9,0))).
free(carla,slot(time(10,0),time(10,15))).

free(dave,slot(time(8,0),time(9,0))).
free(dave,slot(time(10,0),time(11,0))).

free(ed,slot(time(9,0),time(10,0))).
